create database quizmania;
use quizmania;
create table usuario(
usuario_ID int primary key,
usuario_Nome varchar(40) not null,
usuario_Senha varchar(40) not null,
usuario_Turma varchar(40),
usuario_Rank int(3)
)
