<?php

/*
$databaseHost = '	sql111.epizy.com';
$databaseName = 'epiz_24555346_QuizMania';
$databaseUsername = 'epiz_24555346';
$databasePassword = 'quizmania';
*/
$databaseHost = 'localhost';
$databaseName = 'quizmania';
$databaseUsername = 'quizmania';
$databasePassword = 'quizmania';
$mysqli = mysqli_connect($databaseHost,
$databaseUsername,$databasePassword,$databaseName);
 ?>
