<?php
include_once("config.php");


if (mysqli_query($mysqli,"INSERT INTO usuario(usuario_Nome,usuario_Senha,usuario_Turma) VALUES('".$_POST['nome']."','".$_POST['senha']."','".$_POST['turma']."')")) {
  mysqli_query($mysqli,"INSERT INTO usuario(usuario_Nome,usuario_Senha,usuario_Turma) VALUES('".$_POST['nome']."','".$_POST['senha']."','".$_POST['turma']."')");
  // Header("Location: ../Index.html");
  @session_start();
  $_SESSION['usuario_Nome'] = $_POST['nome'];


  echo "<script>
  alert('Cadastro efetuado com sucesso!,Bem vindo ao QuizMania ".$_SESSION['usuario_Nome']."');
  window.location.replace('../Index.html');

  </script>";

}else{

  // Header("Location: ../Front/Cadastro.html");
  echo "<script>
  alert('Falha ao realizar o cadastro ".$_POST['nome']." tente inserir outras credenciais');
  window.location.replace('../Front/Cadastro.html');

  </script>";

}
 ?>
