
CREATE USER 'quizmania'@'localhost' IDENTIFIED BY 'quizmania';
GRANT ALL PRIVILEGES ON quizmania TO 'quizmania'@'localhost';
